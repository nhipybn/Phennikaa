'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Menu, ChevronDown } from 'lucide-react'

export default function Header() {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="container-max px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo%20pkdk%20pnk%20%C4%91%C4%91-RZLb85hHC7WyhVUxKHtywYosN9TKlX.png"
              alt="PhenikaaMEC"
              width={120}
              height={50}
              className="h-10 w-auto"
            />
          </Link>

          {/* Navigation Menu - Hidden on tablet/mobile */}
          <nav className="hidden lg:flex items-center gap-8 flex-1 mx-12">
            <Link href="#subheadline" className="text-gray-700 font-heading font-bold text-sm hover:text-phenikaa-blue transition">
              Về Webinar
            </Link>
            <Link href="#audience" className="text-gray-700 font-heading font-bold text-sm hover:text-phenikaa-blue transition">
              Đối tượng
            </Link>
            <Link href="#why" className="text-gray-700 font-heading font-bold text-sm hover:text-phenikaa-blue transition">
              Lợi ích
            </Link>
            <Link href="#problems" className="text-gray-700 font-heading font-bold text-sm hover:text-phenikaa-blue transition">
              Vấn đề
            </Link>
            <Link href="#speakers" className="text-gray-700 font-heading font-bold text-sm hover:text-phenikaa-blue transition">
              Diễn giả
            </Link>
            <Link href="#agenda" className="text-gray-700 font-heading font-bold text-sm hover:text-phenikaa-blue transition">
              Chương trình
            </Link>
          </nav>

          {/* Action Buttons - Hidden on tablet/mobile */}
          <div className="hidden lg:flex items-center gap-3">
            <button className="px-6 py-2 bg-phenikaa-blue text-white rounded-lg font-heading font-bold text-sm hover:bg-phenikaa-dark-blue transition duration-200">
              Đăng ký
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition">
            <Menu className="w-6 h-6 text-phenikaa-blue" />
          </button>
        </div>
      </div>
    </header>
  )
}
