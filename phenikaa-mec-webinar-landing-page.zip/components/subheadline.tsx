export default function Subheadline() {
  return (
    <section id="subheadline" className="section-padding bg-gradient-to-b from-white to-gray-50">
      <div className="container-max max-w-3xl">
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-phenikaa-dark-blue mb-6 text-center">
          Tại sao Doanh Nghiệp cần webinar này?
        </h2>

        <div className="space-y-6 text-gray-700 leading-relaxed font-sans">
          <p>
            Trong những năm gần đây, dữ liệu sức khỏe tổng quan của nhân sự ngày càng được nhiều Doanh Nghiệp quan tâm.
          </p>

          <p>
            Tuy nhiên, nhiều Doanh nghiệp chỉ đang dừng lại ở các dữ liệu như:
          </p>

          <ul className="space-y-3 ml-6">
            <li className="flex gap-3">
              <span className="text-phenikaa-blue font-bold">•</span>
              <span>Chi phí y tế đang tăng hay giảm</span>
            </li>
            <li className="flex gap-3">
              <span className="text-phenikaa-blue font-bold">•</span>
              <span>Tỷ lệ sử dụng bảo hiểm thay đổi theo từng năm</span>
            </li>
            <li className="flex gap-3">
              <span className="text-phenikaa-blue font-bold">•</span>
              <span>Những nhóm bệnh đang xuất hiện phổ biến hơn trong workforce</span>
            </li>
          </ul>

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border-l-4 border-phenikaa-orange my-8">
            <p className="font-heading font-bold text-phenikaa-dark-blue mb-4">
              NHƯNG ANH/CHỊ CÓ BIẾT DỮ LIỆU ĐÓ CÓ THỂ TRẢ LỜI ĐƯỢC CÁC CÂU HỎI QUAN TRỌNG HƠN?
            </p>
            <ul className="space-y-3">
              <li className="flex gap-3">
                <span className="text-phenikaa-orange font-bold">✓</span>
                <span className="text-gray-700">Đâu là những rủi ro sức khỏe đang hình thành trong đội ngũ?</span>
              </li>
              <li className="flex gap-3">
                <span className="text-phenikaa-orange font-bold">✓</span>
                <span className="text-gray-700">Nhóm nhân sự nào cần được quan tâm nhiều hơn?</span>
              </li>
              <li className="flex gap-3">
                <span className="text-phenikaa-orange font-bold">✓</span>
                <span className="text-gray-700">Những xu hướng hiện tại sẽ tác động như thế nào đến chi phí và năng suất lao động trong tương lai?</span>
              </li>
            </ul>
          </div>

          <p>
            Khi được kết nối và phân tích đúng cách, dữ liệu không chỉ phản ánh những gì đã xảy ra mà còn giúp doanh nghiệp nhìn thấy các tín hiệu sớm của rủi ro, tối ưu chương trình phúc lợi và đưa ra các quyết định phù hợp hơn trong quản lý sức khỏe workforce.
          </p>

          <p>
            Trong webinar chuyên sâu này, <strong>chuyên gia sức khỏe từ Phenikaa</strong> sẽ chia sẻ cách để các Doanh Nghiệp, Nhân sự, người phụ trách sức khỏe đội ngũ có thể làm việc với dữ liệu sức khỏe tổng quan một cách hiệu quả.
          </p>
        </div>
      </div>
    </section>
  )
}
