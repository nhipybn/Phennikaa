export default function Audience() {
  const audience = [
    {
      role: 'HR Manager / Phụ trách Nhân sự',
      description: 'Người chịu trách nhiệm tổ chức khám sức khỏe định kỳ và phúc lợi nhân viên'
    },
    {
      role: 'HR Admin / GA (Tổng vụ)',
      description: 'Người trực tiếp làm việc với đơn vị khám, quản lý hồ sơ sức khỏe'
    },
    {
      role: 'CEO / Giám đốc SME',
      description: 'Người quyết định ngân sách và chương trình khám sức khỏe (30-100 nhân sự)'
    },
    {
      role: 'C&B / HRBP',
      description: 'Thiết kế gói phúc lợi cần dữ liệu để tư vấn lãnh đạo'
    },
    {
      role: 'Cán bộ HSE / Y tế',
      description: 'Nắm dữ liệu sức khỏe nhưng thiếu công cụ phân tích'
    }
  ]

  return (
    <section id="audience" className="section-padding bg-gradient-to-b from-white to-gray-50">
      <div className="container-max">
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-phenikaa-dark-blue mb-4 text-center">
          Đối tượng tham dự
        </h2>
        <div className="w-16 h-1 bg-phenikaa-orange rounded mx-auto mb-12"></div>
        <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto leading-relaxed">
          Webinar được thiết kế cho những người có trách nhiệm quản lý sức khỏe và phúc lợi nhân sự trong doanh nghiệp
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
          {audience.map((item, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg border border-phenikaa-blue border-opacity-30 hover:shadow-lg transition-all duration-300 hover:border-opacity-50"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-phenikaa-blue to-phenikaa-dark-blue text-white rounded-lg flex items-center justify-center font-heading font-bold text-xl mb-4">
                {index + 1}
              </div>
              <h4 className="font-heading font-bold text-phenikaa-dark-blue mb-2 text-sm leading-tight">
                {item.role}
              </h4>
              <p className="text-xs text-gray-700 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
