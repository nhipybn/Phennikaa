export default function Agenda() {
  const agendaItems = [
    {
      num: '1',
      title: 'Dữ liệu sức khỏe tổng quan là gì?',
      description: 'Những dữ liệu nào Doanh nghiệp có thể khai thác để quản lý sức khỏe workforce'
    },
    {
      num: '2',
      title: 'Khai thác giá trị dữ liệu',
      description: 'Cách khai thác giá trị dữ liệu sức khỏe đang có sẵn một cách hiệu quả'
    },
    {
      num: '3',
      title: 'Phân nhóm ưu tiên',
      description: 'Cách phân nhóm để ưu tiên đúng đối tượng và nhóm nhân sự cần quan tâm'
    },
    {
      num: '4',
      title: 'Xây dựng phúc lợi',
      description: 'Xây dựng chương trình phúc lợi dựa trên bằng chứng và đo lường được'
    },
    {
      num: '5',
      title: 'Dự báo xu hướng',
      description: 'Cách dùng xu hướng hiện tại để dự báo và chủ động lập kế hoạch tương lai'
    },
    {
      num: '6',
      title: 'Q&A',
      description: 'Phiên hỏi đáp trực tiếp với các chuyên gia từ Phenikaa'
    }
  ]

  return (
    <section id="agenda" className="section-padding bg-gradient-to-b from-blue-50 to-white">
      <div className="container-max">
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-phenikaa-dark-blue mb-4 text-center">
          Chương trình Webinar
        </h2>
        <div className="w-16 h-1 bg-phenikaa-orange rounded mx-auto mb-12"></div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agendaItems.map((item, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg border border-phenikaa-blue border-opacity-30 hover:shadow-lg transition-all duration-300"
            >
              <div className="flex items-start gap-4 mb-3">
                <div className="w-12 h-12 bg-phenikaa-blue text-white rounded-lg flex items-center justify-center font-heading font-bold flex-shrink-0">
                  {item.num}
                </div>
                <h3 className="font-heading font-bold text-phenikaa-dark-blue leading-tight">
                  {item.title}
                </h3>
              </div>
              <p className="text-gray-700 text-sm leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
