'use client'

export default function HeroBanner() {
  return (
    <section className="relative w-full bg-gradient-to-br from-phenikaa-blue via-phenikaa-blue to-phenikaa-dark-blue min-h-screen flex items-center pt-20 pb-12 overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-yellow-300 rounded-full opacity-10 blur-3xl"></div>
      <div className="absolute bottom-20 right-20 w-40 h-40 bg-cyan-400 rounded-full opacity-10 blur-3xl"></div>

      <div className="container-max px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
          {/* Left Content */}
          <div className="text-white">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-3 h-3 bg-yellow-300 rounded-full"></div>
              <span className="text-sm font-heading font-bold">WEBINAR ONLINE</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold mb-6 leading-tight">
              Dữ liệu sức khỏe tổng quan
              <span className="block text-yellow-300 mt-2">nói cho Doanh Nghiệp biết điều gì?</span>
            </h1>

            <p className="text-base md:text-lg text-blue-100 mb-8 leading-relaxed max-w-xl">
              Cách phòng ngừa rủi ro, tối ưu phúc lợi và cải thiện sức khỏe đội ngũ bằng dữ liệu sức khỏe tổng hợp.
            </p>

            {/* Meta Info */}
            <div className="flex flex-wrap gap-6 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-300 rounded-lg flex items-center justify-center">
                  <span className="text-lg">📅</span>
                </div>
                <div>
                  <div className="text-xs text-blue-200">Ngày</div>
                  <div className="font-heading font-bold">Đang xác nhận</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-300 rounded-lg flex items-center justify-center">
                  <span className="text-lg">⏰</span>
                </div>
                <div>
                  <div className="text-xs text-blue-200">Giờ</div>
                  <div className="font-heading font-bold">10:00 AM - End</div>
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <button className="px-8 py-3 bg-yellow-300 text-phenikaa-dark-blue font-heading font-bold rounded-full hover:bg-yellow-400 transition-colors duration-200 shadow-lg hover:shadow-xl">
              Đăng Ký Ngay
            </button>

            {/* Additional Info */}
            <p className="text-xs text-blue-200 mt-6 max-w-lg">
              <strong>Hình thức:</strong> Online (Zoom link sẽ được gửi sau khi đăng ký)
            </p>
          </div>

          {/* Right - Illustration */}
          <div className="relative h-96 md:h-full flex items-center justify-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              <div className="absolute inset-0 bg-white rounded-full opacity-20 blur-2xl"></div>
              <div className="relative bg-white rounded-full w-full h-full flex items-center justify-center shadow-2xl">
                <div className="text-center">
                  <div className="text-8xl mb-4">📊</div>
                  <p className="text-phenikaa-blue font-heading font-bold">Health Data</p>
                  <p className="text-sm text-gray-500">Analytics & Insights</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
