'use client'

import { Heart, Briefcase } from 'lucide-react'

export default function Speakers() {
  const speakers = [
    {
      name: 'Chuyên gia Sức khỏe',
      title: 'Phenikaa Medical Group',
      bio: 'Với hơn 10 năm kinh nghiệm trong lĩnh vực y tế doanh nghiệp',
      Icon: Heart
    },
    {
      name: 'Chuyên gia Nhân sự',
      title: 'Phenikaa HR Solutions',
      bio: 'Giàu kinh nghiệm trong quản lý nhân sự và phúc lợi doanh nghiệp',
      Icon: Briefcase
    }
  ]

  return (
    <section id="speakers" className="section-padding bg-white">
      <div className="container-max">
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-phenikaa-dark-blue mb-4 text-center">
          Thông tin về Speaker
        </h2>
        <div className="w-16 h-1 bg-phenikaa-orange rounded mx-auto mb-12"></div>

        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {speakers.map((speaker, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-blue-50 to-white p-8 rounded-lg border border-phenikaa-blue border-opacity-40 hover:shadow-lg transition-all duration-300 text-center"
            >
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-phenikaa-blue to-phenikaa-dark-blue rounded-full flex items-center justify-center">
                  <speaker.Icon className="w-8 h-8 text-white" />
                </div>
              </div>
              <h3 className="font-heading font-bold text-phenikaa-dark-blue text-xl mb-1">
                {speaker.name}
              </h3>
              <p className="text-phenikaa-blue font-heading font-bold text-sm mb-3">
                {speaker.title}
              </p>
              <p className="text-gray-700 leading-relaxed text-sm">
                {speaker.bio}
              </p>
              <div className="mt-4 pt-4 border-t border-phenikaa-blue border-opacity-20">
                <p className="text-xs text-gray-600">
                  Chia sẻ kiến thức thực tiễn và giải pháp cụ thể từ doanh nghiệp
                </p>
              </div>
            </div>
          ))}
        </div>

        <p className="text-center text-gray-700 mt-12 max-w-2xl mx-auto leading-relaxed">
          2 vị chuyên gia từ Phenikaa sẽ chia sẻ cách để Doanh Nghiệp có thể làm việc với dữ liệu sức khỏe tổng quan một cách hiệu quả nhất.
        </p>
      </div>
    </section>
  )
}
