export default function WhyWebinar() {
  const reasons = [
    {
      title: 'Phát hiện tín hiệu sớm',
      description: 'Nhận diện các vấn đề sức khỏe của đội ngũ để giảm nghỉ ốm, cải thiện năng suất và kiểm soát chi phí bảo hiểm.'
    },
    {
      title: 'Chi tiêu một cách thông minh',
      description: 'Biết nhóm nhân sự nào cần gì để ngân sách tạo tác động thực, thay vì thiết kế phúc lợi theo cảm tính.'
    },
    {
      title: 'Trở thành chiến lược gia',
      description: 'Thay đổi vị thế HR từ vận hành thành chiến lược, là đội ngũ hỗ trợ lãnh đạo bằng dữ liệu và dự báo.'
    },
    {
      title: 'Tăng tiếng nói của HR',
      description: 'Đưa tiếng nói của HR vào quyết định ngân sách với dữ liệu thực tế, hoàn toàn khác biệt so với trước.'
    },
    {
      title: 'Phương pháp đơn giản',
      description: 'Áp dụng ngay mà không cần đội phân tích hay hệ thống phức tạp, phù hợp cả doanh nghiệp từ 30 nhân sự.'
    }
  ]

  return (
    <section id="why" className="section-padding bg-gradient-to-b from-white to-blue-50">
      <div className="container-max">
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-phenikaa-dark-blue mb-4 text-center">
          Lý do không thể bỏ lỡ webinar này?
        </h2>
        <div className="w-16 h-1 bg-phenikaa-orange rounded mx-auto mb-12"></div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg border border-phenikaa-blue border-opacity-40 hover:shadow-lg hover:border-opacity-60 transition-all duration-300"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-phenikaa-blue to-phenikaa-dark-blue text-white rounded-full flex items-center justify-center font-heading font-bold flex-shrink-0">
                  {index + 1}
                </div>
                <h3 className="font-heading font-bold text-phenikaa-dark-blue text-lg leading-tight">
                  {reason.title}
                </h3>
              </div>
              <p className="text-gray-700 leading-relaxed text-sm">
                {reason.description}
              </p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-phenikaa-blue to-phenikaa-dark-blue text-white p-8 rounded-lg text-center shadow-lg">
          <p className="text-lg font-heading font-bold mb-4">
            Biến chi phí bắt buộc thành tài sản giá trị cho doanh nghiệp của bạn
          </p>
          <button className="px-8 py-3 bg-phenikaa-orange text-white font-heading font-bold rounded-lg hover:bg-orange-600 transition-colors duration-200">
            Đăng Ký Ngay Để Đảm Bảo Chỗ
          </button>
        </div>
      </div>
    </section>
  )
}
