import Image from 'next/image'
import { MapPin, Phone, Mail, Clock } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-phenikaa-dark-blue text-white">
      <div className="container-max section-padding">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* About */}
          <div>
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo%20pkdk%20pnk%20%C4%91%C4%91-RZLb85hHC7WyhVUxKHtywYosN9TKlX.png"
              alt="Phenikaa Medical Clinic"
              width={140}
              height={50}
              className="h-12 w-auto mb-4"
            />
            <p className="text-blue-100 text-sm leading-relaxed">
              Phòng khám đa khoa Phenikaa - Thành viên của tập đoàn Phenikaa, cung cấp dịch vụ y tế chất lượng cao.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-bold text-white mb-4 capitalize">Về chúng tôi</h4>
            <ul className="space-y-2 text-blue-100 text-sm">
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Giới thiệu
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Chuyên khoa
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Dịch vụ
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Tìm bác sĩ
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Tin tức
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-heading font-bold text-white mb-4 capitalize">Dịch vụ</h4>
            <ul className="space-y-2 text-blue-100 text-sm">
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Khám tổng quát
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Khám chuyên khoa
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Xét nghiệm
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Chụp X-quang
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Siêu âm
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading font-bold text-white mb-4 capitalize">Liên hệ</h4>
            <ul className="space-y-3 text-blue-100 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                <span>Phenikaa Medical Clinic</span>
              </li>
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 mt-1 flex-shrink-0" />
                <a href="tel:1900886648" className="hover:text-white transition-colors">
                  1900 886648
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 mt-1 flex-shrink-0" />
                <a href="mailto:info@phenikaamec.com" className="hover:text-white transition-colors">
                  info@phenikaamec.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 mt-1 flex-shrink-0" />
                <span>24/7</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-400 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center text-blue-100 text-sm gap-4">
            <p>
              © 2024 Phenikaa Medical Clinic. Tất cả quyền được bảo lưu.
            </p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">
                Chính sách bảo mật
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Điều khoản sử dụng
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Sitemap
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
