'use client'

import { useState } from 'react'

export default function RegistrationForm() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    position: '',
    message: '',
  })

  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Form submitted:', formData)
    setSubmitted(true)
    setTimeout(() => {
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        company: '',
        position: '',
        message: '',
      })
      setSubmitted(false)
    }, 3000)
  }

  return (
    <section className="section-padding bg-white">
      <div className="container-max">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-phenikaa-dark-blue mb-4 text-center">
            Đăng Ký Ngay
          </h2>
          <div className="w-16 h-1 bg-phenikaa-orange rounded mx-auto mb-12"></div>

          {submitted ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
              <div className="text-4xl mb-4">✓</div>
              <h3 className="text-xl font-heading font-bold text-green-800 mb-2">
                Đăng ký thành công!
              </h3>
              <p className="text-green-700">
                Cảm ơn bạn đã đăng ký. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-heading font-bold text-phenikaa-dark-blue mb-2">
                  Họ và tên *
                </label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-phenikaa-blue focus:border-transparent transition"
                  placeholder="Nhập họ và tên"
                />
              </div>

              {/* Email and Phone */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-heading font-bold text-phenikaa-dark-blue mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-phenikaa-blue focus:border-transparent transition"
                    placeholder="email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-heading font-bold text-phenikaa-dark-blue mb-2">
                    Số điện thoại *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-phenikaa-blue focus:border-transparent transition"
                    placeholder="0123456789"
                  />
                </div>
              </div>

              {/* Company and Position */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-heading font-bold text-phenikaa-dark-blue mb-2">
                    Công ty
                  </label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-phenikaa-blue focus:border-transparent transition"
                    placeholder="Tên công ty"
                  />
                </div>
                <div>
                  <label className="block text-sm font-heading font-bold text-phenikaa-dark-blue mb-2">
                    Chức vụ
                  </label>
                  <input
                    type="text"
                    name="position"
                    value={formData.position}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-phenikaa-blue focus:border-transparent transition"
                    placeholder="Chức vụ"
                  />
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-sm font-heading font-bold text-phenikaa-dark-blue mb-2">
                  Tin nhắn
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-phenikaa-blue focus:border-transparent transition resize-none"
                  placeholder="Nhập thông điệp của bạn..."
                ></textarea>
              </div>

              {/* Submit Button */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <button
                  type="submit"
                  className="btn-primary flex-1 text-center"
                >
                  Đăng ký ngay
                </button>
                <button
                  type="reset"
                  className="btn-secondary flex-1 text-center"
                >
                  Xóa
                </button>
              </div>

              <p className="text-xs text-gray-500 text-center mt-4">
                (*) Là những trường bắt buộc
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}
