export default function Problems() {
  const problems = [
    {
      num: '1',
      title: 'Khai thác giá trị dữ liệu',
      description: 'Chỉ cách khai thác đúng giá trị của dữ liệu tổng quan đang có sẵn'
    },
    {
      num: '2',
      title: 'Nhận diện tín hiệu sớm',
      description: 'Hướng dẫn cách nhận diện tín hiệu sớm: Bệnh chuyển hóa, cơ xương khớp, sức khỏe tinh thần'
    },
    {
      num: '3',
      title: 'Phân nhóm ưu tiên',
      description: 'Cách phân nhóm để ưu tiên đúng đối tượng: Nhóm nhân sự nào cần được quan tâm hơn'
    },
    {
      num: '4',
      title: 'Xây dựng phúc lợi',
      description: 'Giúp xây dựng phúc lợi dựa trên bằng chứng và đo lường được'
    },
    {
      num: '5',
      title: 'Dự báo xu hướng',
      description: 'Cách dùng xu hướng hiện tại để dự báo và chủ động lập kế hoạch'
    },
    {
      num: '6',
      title: 'Tránh bị động',
      description: 'Dự báo được tác động đến chi phí và năng suất tương lai, tránh bị động'
    }
  ]

  return (
    <section id="problems" className="section-padding bg-gradient-to-b from-orange-50 to-white">
      <div className="container-max">
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-phenikaa-dark-blue mb-4 text-center">
          Webinar này giải quyết vấn đề gì?
        </h2>
        <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto">
          Được đức kết từ dữ liệu thực tế và kinh nghiệm đông hành cung hàng ngân doanh nghiệp.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {problems.map((item, index) => (
            <div
              key={index}
              className="relative bg-white p-6 rounded-lg border border-phenikaa-blue border-opacity-20 hover:border-opacity-40 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-phenikaa-blue to-transparent rounded-l-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <div className="flex items-start gap-4 mb-3">
                <div className="w-12 h-12 bg-phenikaa-orange text-white rounded-lg flex items-center justify-center font-heading font-bold text-lg flex-shrink-0">
                  {item.num}
                </div>
                <h3 className="font-heading font-bold text-phenikaa-dark-blue text-lg leading-tight">
                  {item.title}
                </h3>
              </div>

              <p className="text-gray-700 text-sm leading-relaxed ml-16">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-700 text-lg mb-6 max-w-2xl mx-auto font-heading font-bold">
            Phương pháp đơn giản, áp dụng ngay - không cần đội phân tích hay hệ thống phức tạp
          </p>
          <p className="text-gray-600 text-sm">
            Chuyên gia sức khỏe từ Phenikaa chia sẻ cách làm việc với dữ liệu Doanh Nghiệp được phép biết
          </p>
        </div>
      </div>
    </section>
  )
}
